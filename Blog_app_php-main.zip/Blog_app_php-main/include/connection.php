<?php 
    $con = mysqli_connect('localhost', "root", "", "blog_app") or die("Connection to database could not be established");
?>