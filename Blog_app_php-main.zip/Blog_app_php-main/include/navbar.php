<?php 
    echo "<nav class='navbar'>
        <a href = 'landing-page.php'>Home</a>
        <a href='add_blog_page.php'>Upload</a>
        <a href='about.html'>About</a>
    </nav>";
?>